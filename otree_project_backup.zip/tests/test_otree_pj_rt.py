#!/usr/bin/env python

"""Tests for `otree_pj_rt` package."""


import unittest

from otree_pj_rt import otree_pj_rt


class TestOtree_pj_rt(unittest.TestCase):
    """Tests for `otree_pj_rt` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
