=================
oTree Projects RT
=================


.. image:: https://img.shields.io/pypi/v/otree_pj_rt.svg
        :target: https://pypi.python.org/pypi/otree_pj_rt

.. image:: https://img.shields.io/travis/ryu-thakahashi/otree_pj_rt.svg
        :target: https://travis-ci.com/ryu-thakahashi/otree_pj_rt

.. image:: https://readthedocs.org/projects/otree-pj-rt/badge/?version=latest
        :target: https://otree-pj-rt.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




This directory contains oTree projects created by Ryu Takahashi


* Free software: MIT license
* Documentation: https://otree-pj-rt.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
