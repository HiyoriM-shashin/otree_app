=====
Usage
=====

To use oTree Projects RT in a project::

    import otree_pj_rt
