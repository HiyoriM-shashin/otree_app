"""Top-level package for oTree Projects RT."""

__author__ = """Ryu Takahashi"""
__email__ = 'ryu.takahashi2718@gmail.com'
__version__ = '0.1.0'
